const START = Date.now();

function fmtUptime(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0');
}

function escapeHtml(str) {
  return (str || '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

async function refresh() {
  try {
    const [statsRes, eventsRes] = await Promise.all([
      fetch('/_waf/api/stats'), fetch('/_waf/api/events')
    ]);
    const stats = await statsRes.json();
    const events = (await eventsRes.json()).events;

    document.getElementById('upstream-label').textContent = 'protecting ' + stats.upstream;
    document.getElementById('uptime-label').textContent = 'session ' + fmtUptime(Date.now() - START);

    const t = stats.totals;
    document.getElementById('stat-total').textContent = t.requests;
    document.getElementById('stat-allowed').textContent = t.allowed;
    document.getElementById('stat-blocked').textContent = t.blocked;
    const rate = t.requests ? Math.round((t.blocked / t.requests) * 100) : 0;
    document.getElementById('stat-rate').textContent = rate + '%';

    const strip = document.getElementById('pulse-strip');
    strip.innerHTML = '';
    stats.pulse.forEach(v => {
      const bar = document.createElement('div');
      bar.className = 'pulse-bar' + (v ? ' blocked' : '');
      bar.style.height = (v ? 28 : 10) + 'px';
      strip.appendChild(bar);
    });

    const cats = Object.entries(stats.by_category).sort((a, b) => b[1] - a[1]);
    const catList = document.getElementById('cat-list');
    if (cats.length === 0) {
      catList.innerHTML = '<div class="empty">No data yet</div>';
    } else {
      const max = Math.max(...cats.map(c => c[1]));
      catList.innerHTML = cats.map(([name, count]) => `
        <div class="cat-row">
          <span>${escapeHtml(name)}</span>
          <div class="cat-bar-bg"><div class="cat-bar" style="width:${(count / max * 100).toFixed(0)}%"></div></div>
          <span>${count}</span>
        </div>`).join('');
    }

    const ipList = document.getElementById('ip-list');
    if (stats.top_ips.length === 0) {
      ipList.innerHTML = '<div class="empty">No data yet</div>';
    } else {
      ipList.innerHTML = stats.top_ips.map(r => `
        <div class="ip-row"><span>${escapeHtml(r.ip)}</span><span class="mono-dim">${r.blocked} blocked</span></div>
      `).join('');
    }

    document.getElementById('events-count').textContent = events.length + ' shown';
    const body = document.getElementById('events-body');
    if (events.length === 0) {
      body.innerHTML = '<tr><td colspan="6" class="empty">No attacks blocked yet — traffic is clean.</td></tr>';
    } else {
      body.innerHTML = events.map(e => `
        <tr>
          <td class="mono-dim">${escapeHtml((e.ts || '').split('T')[1]?.replace('+00:00', '') || e.ts)}</td>
          <td>${escapeHtml(e.ip)}</td>
          <td>${escapeHtml(e.category)} <span class="mono-dim">(${escapeHtml(e.rule_id)})</span></td>
          <td><span class="sev sev-${e.severity}">${escapeHtml(e.severity)}</span></td>
          <td class="mono-dim">${escapeHtml(e.method)} ${escapeHtml(e.path)}</td>
          <td><span class="payload">${escapeHtml(e.matched_value)}</span></td>
        </tr>`).join('');
    }
  } catch (err) {
    console.error('Sentinel dashboard refresh failed', err);
  }
}

refresh();
setInterval(refresh, 2000);
