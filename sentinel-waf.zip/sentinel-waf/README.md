# Sentinel — Web Application Firewall (Reverse Proxy)

Sentinel sits between your users and a web application, inspecting every
request for **SQL injection**, **XSS**, **command injection**, and **path
traversal** before it ever reaches the app. Malicious requests are blocked
with a `403` and logged to a SQLite database; everything else is
transparently proxied through. A live dashboard shows blocked attacks,
traffic volume, and top offending IPs in real time.

Built as a learning / portfolio project to demonstrate the core mechanics
behind real WAFs: request inspection, signature-based detection, blocking,
persistence, and observability.

> ⚠️ **Lab use only.** Sentinel is a signature-based demonstration WAF, not a
> production security control. Only point it at applications you own or are
> explicitly authorized to test, such as [DVWA](https://github.com/digininja/DVWA).

---

## Features

- **Reverse proxy** — transparently forwards clean traffic to any upstream HTTP app.
- **Detection engine** — 20+ regex signatures across 4 categories, scanning the
  request path, query string, form body, JSON/raw body, cookies, and headers.
- **Persistent history** — every request (allowed or blocked) is written to a
  SQLite database, so dashboard stats survive restarts.
- **Live dashboard** — dark, SOC-style UI at `/_waf/dashboard`, polling a JSON
  API every 2 seconds: traffic pulse, block rate, category breakdown, top
  attacker IPs, and a live blocked-request table.
- **Dockerized lab** — `docker compose up` gives you Sentinel + DVWA wired
  together in one command.

---

## Architecture

```
                  ┌─────────────────────────────────────────┐
                  │                 Sentinel                 │
  Client  ──────▶ │  before_request gate                     │
                  │    ├─ inspect_request()  (engine.py)      │
                  │    │     └─ RULES        (rules.py)       │
                  │    ├─ blocked?  → 403 + db.record_event   │
                  │    └─ clean?    → forward_request()       │──────▶  Upstream App
                  │                        (proxy.py)          │        (e.g. DVWA)
                  │                                            │
                  │  /_waf/dashboard, /_waf/api/*  (routes.py) │
                  │        └─ reads from  db.py  (SQLite)      │
                  └─────────────────────────────────────────┘
```

```
sentinel-waf/
├── app.py                   # entry point: WAF gate + proxy route + blueprint registration
├── sentinel/
│   ├── config.py              # env-based configuration
│   ├── rules.py                # detection signatures
│   ├── engine.py                # request inspection engine
│   ├── db.py                     # SQLite persistence layer
│   ├── proxy.py                   # reverse proxy forwarding
│   └── routes.py                   # dashboard page + JSON API blueprint
├── templates/dashboard.html
├── static/css/dashboard.css
├── static/js/dashboard.js
├── requirements.txt
├── .env.example
├── Dockerfile
├── docker-compose.yml
└── LICENSE
```

---

## Quick start (local)

```bash
git clone <your-repo-url> sentinel-waf
cd sentinel-waf
pip install -r requirements.txt

cp .env.example .env      # edit WAF_UPSTREAM to point at the app you're protecting
export $(cat .env | xargs)

python app.py
```

- Protected app (through the firewall): **http://127.0.0.1:8000/**
- Live dashboard: **http://127.0.0.1:8000/_waf/dashboard**

Trip a rule to see it in action:

```bash
curl "http://127.0.0.1:8000/vulnerabilities/sqli/?id=1' OR '1'='1"
curl "http://127.0.0.1:8000/?q=<script>alert(1)</script>"
curl "http://127.0.0.1:8000/?cmd=;cat%20/etc/passwd"
```

Refresh the dashboard and each attempt shows up with its rule ID, category,
severity, and the exact payload that tripped it.

---

## Quick start (Docker — Sentinel + DVWA in one command)

```bash
docker compose up --build
```

- Vulnerable app directly (bypasses the WAF, useful for comparison): `http://localhost:8081`
- Through Sentinel (protected): `http://localhost:8000`
- Dashboard: `http://localhost:8000/_waf/dashboard`

First run: visit `http://localhost:8000/setup.php`, click **Create / Reset
Database**, then log in with `admin` / `password`. Set DVWA's security level
to **low** or **medium** under "DVWA Security" and start firing payloads at
it through port `8000` — watch them get caught live on the dashboard.

---

## Configuration

All configuration is environment variables (see `.env.example`):

| Variable | Default | Description |
|---|---|---|
| `WAF_UPSTREAM` | `http://127.0.0.1:8081` | The app Sentinel protects |
| `WAF_PORT` | `8000` | Port Sentinel listens on |
| `WAF_DB_PATH` | `sentinel.db` | SQLite database file |
| `WAF_REQUEST_TIMEOUT` | `10` | Upstream proxy timeout, in seconds |
| `WAF_MAX_EVENTS` | `200` | Max events returned per dashboard fetch |
| `WAF_PULSE_WINDOW` | `80` | How many recent requests feed the live pulse strip |

---

## Detection rules

Rules live in `sentinel/rules.py` as `(rule_id, category, severity,
description, regex)` tuples — add a new one and it's active immediately,
nothing else needs to change.

| Category | Example rule IDs | What it catches |
|---|---|---|
| SQL Injection | `SQLI-001`–`SQLI-010` | UNION SELECT, tautologies (`OR 1=1`), comment terminators, `SLEEP`/`BENCHMARK`, `information_schema` enumeration, destructive DDL, stacked queries, hex obfuscation |
| XSS | `XSS-001`–`XSS-008` | `<script>` tags, `javascript:` URIs, event-handler injection (`onerror=`, `onload=`), `document.cookie` access, `eval()`, encoded script tags |
| Command Injection | `CMDI-001`–`CMDI-005` | Chained shell metacharacters, command substitution (`` `cmd` `` / `$(cmd)`), reads of `/etc/passwd`, reverse-shell patterns |
| Path Traversal | `TRAV-001`–`TRAV-002` | `../../` sequences, URL-encoded traversal |

**How matching works:** on every request, Sentinel extracts every
attacker-influenced string — path, query params, form fields, JSON/raw body,
cookies, and a few commonly abused headers — and checks each one against
every rule. The first match blocks the request with a `403` and is logged
with its rule ID, category, severity, and the exact matched substring.

---

## API reference

| Endpoint | Description |
|---|---|
| `GET /_waf/dashboard` | The live dashboard UI |
| `GET /_waf/api/stats` | JSON: totals, block rate, attacks by category, top IPs, pulse data |
| `GET /_waf/api/events?limit=200` | JSON: most recent blocked events, newest first |

The `/_waf/*` prefix is reserved for Sentinel itself and is excluded from
proxying — make sure the app you're protecting doesn't already use it.

---

## Limitations & honest scope

This is a signature-based demonstration WAF, built to be read and understood
end to end in one sitting. It intentionally does **not** include:

- TLS termination (put it behind nginx/Caddy or a load balancer for that)
- ML-based or statistical anomaly scoring — only regex signatures
- Rate limiting / brute-force protection
- Hot-reloading rules without a restart
- Distributed/clustered deployment (SQLite is single-node)

These are natural next steps if you want to extend it further.

---

## License

MIT — see [LICENSE](LICENSE).
