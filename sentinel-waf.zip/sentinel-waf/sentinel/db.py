"""
SQLite persistence layer.

Every request Sentinel sees (allowed or blocked) is written to a single
`events` table. This keeps the dashboard's numbers accurate across restarts
and gives you a real, queryable audit trail instead of an in-memory log that
vanishes when the process exits.

SQLite handles this workload comfortably at reverse-proxy scale; a short
per-call connection with WAL mode keeps writes safe under concurrent
requests without needing an external database server.
"""

import sqlite3
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone

_db_path = "sentinel.db"


def init_db(db_path):
    """Create the database file and schema if they don't already exist.
    Call once at application startup."""
    global _db_path
    _db_path = db_path
    with _connect() as conn:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id            TEXT PRIMARY KEY,
                ts            TEXT NOT NULL,
                ip            TEXT NOT NULL,
                method        TEXT NOT NULL,
                path          TEXT NOT NULL,
                blocked       INTEGER NOT NULL,
                category      TEXT,
                rule_id       TEXT,
                severity      TEXT,
                description   TEXT,
                matched_value TEXT
            );
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_blocked ON events(blocked);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_ip ON events(ip);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_category ON events(category);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);")
        conn.commit()


@contextmanager
def _connect():
    conn = sqlite3.connect(_db_path, timeout=5)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def _now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def record_event(ip, method, path, blocked, category=None, rule_id=None,
                  severity=None, description=None, matched_value=None):
    """Persist one request outcome. `blocked=False` events are stored too so
    traffic totals and block-rate stay accurate."""
    event_id = str(uuid.uuid4())[:8]
    with _connect() as conn:
        conn.execute(
            """INSERT INTO events
               (id, ts, ip, method, path, blocked, category, rule_id, severity, description, matched_value)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (event_id, _now_iso(), ip, method, path[:300], int(blocked),
             category, rule_id, severity, description,
             (matched_value or "")[:200] if blocked else None),
        )
        conn.commit()
    return event_id


def get_stats(pulse_window=80):
    """Aggregate totals, blocked-by-category, top offending IPs, and a
    rolling allow/block 'pulse' for the dashboard — computed live from the
    events table, so numbers survive restarts."""
    with _connect() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS total, SUM(blocked) AS blocked FROM events"
        ).fetchone()
        total = row["total"] or 0
        blocked = row["blocked"] or 0

        by_category = conn.execute(
            """SELECT category, COUNT(*) AS n FROM events
               WHERE blocked = 1 GROUP BY category ORDER BY n DESC"""
        ).fetchall()

        top_ips = conn.execute(
            """SELECT ip, COUNT(*) AS n FROM events
               WHERE blocked = 1 GROUP BY ip ORDER BY n DESC LIMIT 6"""
        ).fetchall()

        pulse_rows = conn.execute(
            "SELECT blocked FROM events ORDER BY rowid DESC LIMIT ?", (pulse_window,)
        ).fetchall()

    return {
        "totals": {"requests": total, "blocked": blocked, "allowed": total - blocked},
        "by_category": {r["category"]: r["n"] for r in by_category},
        "top_ips": [{"ip": r["ip"], "blocked": r["n"]} for r in top_ips],
        "pulse": [r["blocked"] for r in reversed(pulse_rows)],
    }


def get_recent_events(limit=200):
    """Return the most recent blocked events, newest first."""
    with _connect() as conn:
        rows = conn.execute(
            """SELECT id, ts, ip, method, path, category, rule_id, severity, description, matched_value
               FROM events WHERE blocked = 1
               ORDER BY rowid DESC LIMIT ?""", (limit,)
        ).fetchall()
    return [dict(r) for r in rows]
