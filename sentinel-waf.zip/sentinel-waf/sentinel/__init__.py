"""Sentinel — a signature-based Web Application Firewall (reverse proxy)."""

__version__ = "1.0.0"
