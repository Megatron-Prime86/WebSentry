"""
Configuration for Sentinel, loaded entirely from environment variables so the
same code runs unmodified in local dev, Docker, and CI.
"""

import os


class Config:
    # The application Sentinel protects. In Docker Compose this is the
    # service name of the target container (e.g. http://dvwa:80).
    UPSTREAM = os.environ.get("WAF_UPSTREAM", "http://127.0.0.1:8081").rstrip("/")

    # Port Sentinel itself listens on.
    PORT = int(os.environ.get("WAF_PORT", "8000"))

    # SQLite database file used to persist every allowed/blocked request.
    DB_PATH = os.environ.get("WAF_DB_PATH", "sentinel.db")

    # Outbound proxy timeout, in seconds.
    REQUEST_TIMEOUT = int(os.environ.get("WAF_REQUEST_TIMEOUT", "10"))

    # How many recent events the dashboard requests at once.
    MAX_EVENTS_RETURNED = int(os.environ.get("WAF_MAX_EVENTS", "200"))

    # How many recent request outcomes feed the live "pulse" strip.
    PULSE_WINDOW = int(os.environ.get("WAF_PULSE_WINDOW", "80"))

    # Headers that must never be blindly forwarded between client and upstream.
    HOP_BY_HOP_HEADERS = {
        "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
        "te", "trailers", "transfer-encoding", "upgrade", "content-length", "host",
    }

    # Reserved path prefix for Sentinel's own dashboard/API — never proxied.
    ADMIN_PREFIX = "/_waf"
