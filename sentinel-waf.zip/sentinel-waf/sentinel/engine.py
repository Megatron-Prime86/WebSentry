"""
Detection engine — pulls every attacker-influenced string off a Flask request
(path, query, form body, JSON/raw body, cookies, a few headers) and runs the
rule set from `rules.py` against each one.
"""

from urllib.parse import unquote_plus

from .rules import RULES


def _candidate_strings(request):
    """Collect every attacker-influenced string on the request, tagged with
    where it came from (used for nicer dashboard/incident output)."""
    items = [
        ("path", unquote_plus(request.path)),
        ("query", unquote_plus(request.query_string.decode("utf-8", "ignore"))),
    ]

    for key, val in request.args.items():
        items.append((f"query_param:{key}", unquote_plus(val)))

    try:
        for key, val in request.form.items():
            items.append((f"form_field:{key}", unquote_plus(val)))
    except Exception:
        pass

    try:
        raw = request.get_data(cache=True, as_text=True) or ""
        if raw and request.content_type and "json" in request.content_type:
            items.append(("json_body", raw))
        elif raw and not request.form:
            items.append(("raw_body", raw))
    except Exception:
        pass

    for cname, cval in request.cookies.items():
        items.append((f"cookie:{cname}", cval))
    for hname in ("User-Agent", "Referer", "X-Forwarded-For"):
        hval = request.headers.get(hname)
        if hval:
            items.append((f"header:{hname}", hval))

    return items


def inspect_request(request):
    """Run every rule against every candidate string on the request.

    Returns a dict describing the first match found, or None if the request
    looks clean. Rules are checked in the order defined in rules.py, so list
    your highest-confidence/highest-severity rules first within a category.
    """
    candidates = _candidate_strings(request)
    for rule_id, category, severity, description, pattern in RULES:
        for source, value in candidates:
            if not value:
                continue
            match = pattern.search(value)
            if match:
                return {
                    "rule_id": rule_id,
                    "category": category,
                    "severity": severity,
                    "description": description,
                    "source": source,
                    "matched_value": match.group(0),
                }
    return None
