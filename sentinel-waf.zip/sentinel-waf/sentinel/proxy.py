"""Forwards a clean (non-blocked) request to the protected upstream app and
streams its response back to the client untouched."""

import requests
from flask import Response, jsonify

from .config import Config


def forward_request(request, path):
    target_url = f"{Config.UPSTREAM}/{path}"

    outbound_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in Config.HOP_BY_HOP_HEADERS
    }

    try:
        upstream_resp = requests.request(
            method=request.method,
            url=target_url,
            params=request.args,
            headers=outbound_headers,
            data=request.get_data(),
            cookies=request.cookies,
            allow_redirects=False,
            timeout=Config.REQUEST_TIMEOUT,
            stream=True,
        )
    except requests.exceptions.ConnectionError:
        return jsonify({
            "error": "upstream_unreachable",
            "message": f"Sentinel could not reach the protected app at {Config.UPSTREAM}. "
                       f"Is it running? Set WAF_UPSTREAM to change the target.",
        }), 502
    except requests.exceptions.Timeout:
        return jsonify({"error": "upstream_timeout"}), 504

    response_headers = [
        (k, v) for k, v in upstream_resp.raw.headers.items()
        if k.lower() not in Config.HOP_BY_HOP_HEADERS
    ]
    return Response(upstream_resp.content, upstream_resp.status_code, response_headers)
