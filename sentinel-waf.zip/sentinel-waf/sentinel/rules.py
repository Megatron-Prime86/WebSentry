"""
Detection signatures.

Each rule is (rule_id, category, severity, description, compiled regex).
Severity is "high" | "medium" | "low" and drives dashboard coloring.
Patterns are case-insensitive and tuned to catch classic lab-style payloads
(DVWA, WebGoat, bWAPP) without being so broad they choke on ordinary text.

Add a new rule by appending a call to `_rule(...)` to the relevant section —
nothing else in the codebase needs to change.
"""

import re


def _rule(rule_id, category, severity, description, pattern):
    return (rule_id, category, severity, description, re.compile(pattern, re.IGNORECASE | re.DOTALL))


RULES = [
    # ---------------------------------------------------------------- SQLi --
    _rule("SQLI-001", "SQL Injection", "high", "UNION-based SELECT",
          r"\bunion\b[\s/*]{1,20}\bselect\b"),
    _rule("SQLI-002", "SQL Injection", "high", "Tautology (OR/AND 1=1 style)",
          r"(\bor\b|\band\b)\s+['\"]?\s*\d+\s*=\s*\d+"),
    _rule("SQLI-003", "SQL Injection", "high", "Classic quote-breakout tautology",
          r"['\"]\s*(or|and)\s*['\"]?\s*\w*\s*['\"]?\s*=\s*['\"]?\s*\w*"),
    _rule("SQLI-004", "SQL Injection", "medium", "SQL comment terminator",
          r"(--|#|/\*)\s*$|'\s*--"),
    _rule("SQLI-005", "SQL Injection", "high", "Time-based blind (SLEEP/BENCHMARK/WAITFOR)",
          r"\b(sleep|benchmark)\s*\(\s*\d+|waitfor\s+delay\s+['\"]"),
    _rule("SQLI-006", "SQL Injection", "high", "information_schema enumeration",
          r"information_schema|sysobjects|sys\.tables"),
    _rule("SQLI-007", "SQL Injection", "high", "Destructive DDL/DML statement",
          r"\b(drop|truncate|alter)\s+table\b|\bexec(ute)?\s+xp_cmdshell\b"),
    _rule("SQLI-008", "SQL Injection", "medium", "Stacked/chained query",
          r";\s*(select|insert|update|delete|drop)\s"),
    _rule("SQLI-009", "SQL Injection", "medium", "Hex-encoded literal (obfuscation)",
          r"0x[0-9a-f]{8,}"),
    _rule("SQLI-010", "SQL Injection", "low", "CAST/CONVERT type juggling",
          r"\bcast\s*\(.{1,40}\bas\b|\bconvert\s*\("),

    # ----------------------------------------------------------------- XSS --
    _rule("XSS-001", "XSS", "high", "Inline <script> tag",
          r"<\s*script[^>]*>"),
    _rule("XSS-002", "XSS", "high", "javascript: URI scheme",
          r"javascript\s*:"),
    _rule("XSS-003", "XSS", "high", "Event-handler attribute injection",
          r"\bon(error|load|click|mouseover|focus|change|input|toggle)\s*="),
    _rule("XSS-004", "XSS", "high", "<img>/<svg> onerror/onload payload",
          r"<\s*(img|svg|iframe|body)\b[^>]*\b(onerror|onload)\s*="),
    _rule("XSS-005", "XSS", "medium", "document.cookie / DOM access",
          r"document\s*\.\s*(cookie|location|write)"),
    _rule("XSS-006", "XSS", "medium", "eval()/expression() injection",
          r"\beval\s*\(|expression\s*\("),
    _rule("XSS-007", "XSS", "medium", "URL-encoded script tag",
          r"%3c\s*script|%3cscript"),
    _rule("XSS-008", "XSS", "low", "Suspicious alert/prompt/confirm call",
          r"\b(alert|prompt|confirm)\s*\(\s*['\"]?"),

    # ------------------------------------------------------- Command Injection --
    _rule("CMDI-001", "Command Injection", "high", "Shell metachar chained command",
          r"[;&|]{1,2}\s*(ls|cat|whoami|id|pwd|uname|wget|curl|nc|ncat|bash|sh|python[0-9.]*|perl|powershell)\b"),
    _rule("CMDI-002", "Command Injection", "high", "Command substitution ($() or backticks)",
          r"\$\([^)]{1,80}\)|`[^`]{1,80}`"),
    _rule("CMDI-003", "Command Injection", "high", "Direct read of sensitive file",
          r"/etc/passwd|/etc/shadow|boot\.ini|win\.ini"),
    _rule("CMDI-004", "Command Injection", "medium", "Reverse-shell / netcat listener pattern",
          r"\bnc\s+-e\b|/dev/tcp/|\bmkfifo\b"),
    _rule("CMDI-005", "Command Injection", "medium", "Shell interpreter invocation",
          r"\b(/bin/(ba)?sh|/bin/sh)\b"),

    # ----------------------------------------------------------- Path Traversal --
    _rule("TRAV-001", "Path Traversal", "medium", "Directory traversal sequence",
          r"(\.\./|\.\.\\){2,}"),
    _rule("TRAV-002", "Path Traversal", "low", "Encoded traversal sequence",
          r"%2e%2e(%2f|%5c)"),
]
