"""Dashboard page + read-only JSON API. Mounted under Config.ADMIN_PREFIX
and never touched by the WAF gate, so it's always reachable even while the
protected app behind it is being hammered."""

from flask import Blueprint, jsonify, render_template, request

from . import db
from .config import Config

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", upstream=Config.UPSTREAM)


@dashboard_bp.route("/api/stats")
def api_stats():
    stats = db.get_stats(pulse_window=Config.PULSE_WINDOW)
    stats["upstream"] = Config.UPSTREAM
    return jsonify(stats)


@dashboard_bp.route("/api/events")
def api_events():
    limit = min(int(request.args.get("limit", Config.MAX_EVENTS_RETURNED)), 500)
    return jsonify({"events": db.get_recent_events(limit=limit)})
