#!/usr/bin/env python3
"""
================================================================================
 SENTINEL - Web Application Firewall (Reverse Proxy)
================================================================================
Entry point. Wires together the config, detection engine, SQLite persistence,
proxy, and dashboard blueprint from the `sentinel/` package.

    pip install -r requirements.txt
    cp .env.example .env        # then edit WAF_UPSTREAM to point at your app
    python app.py

    Protected app (through the firewall): http://127.0.0.1:8000/
    Live dashboard:                       http://127.0.0.1:8000/_waf/dashboard

See README.md for the full quick-start, rule reference, and Docker setup.
================================================================================
"""

import time

from flask import Flask, jsonify, request

from sentinel import db
from sentinel.config import Config
from sentinel.engine import inspect_request
from sentinel.proxy import forward_request
from sentinel.routes import dashboard_bp

app = Flask(__name__)
app.register_blueprint(dashboard_bp, url_prefix=Config.ADMIN_PREFIX)

_start_time = time.time()


def _client_ip():
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.remote_addr or "unknown"


@app.before_request
def waf_gate():
    # Never inspect/proxy Sentinel's own dashboard & API namespace.
    if request.path.startswith(Config.ADMIN_PREFIX):
        return None

    match = inspect_request(request)
    ip = _client_ip()

    if match:
        db.record_event(
            ip=ip, method=request.method, path=request.full_path, blocked=True,
            category=match["category"], rule_id=match["rule_id"],
            severity=match["severity"], description=match["description"],
            matched_value=f'[{match["source"]}] {match["matched_value"]}',
        )
        return jsonify({
            "blocked": True,
            "message": "Request blocked by Sentinel WAF",
            "rule_id": match["rule_id"],
            "category": match["category"],
            "severity": match["severity"],
            "reason": match["description"],
        }), 403

    db.record_event(ip=ip, method=request.method, path=request.full_path, blocked=False)
    return None  # fall through to the proxy view


@app.route("/", defaults={"path": ""},
           methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
@app.route("/<path:path>",
           methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
def proxy(path):
    return forward_request(request, path)


if __name__ == "__main__":
    db.init_db(Config.DB_PATH)
    print(f"[Sentinel] Protecting upstream: {Config.UPSTREAM}")
    print(f"[Sentinel] Proxy listening on:  http://0.0.0.0:{Config.PORT}/")
    print(f"[Sentinel] Dashboard:           http://0.0.0.0:{Config.PORT}{Config.ADMIN_PREFIX}/dashboard")
    print(f"[Sentinel] Database:            {Config.DB_PATH}")
    app.run(host="0.0.0.0", port=Config.PORT, threaded=True)
else:
    # Also initialize when imported by a WSGI server (gunicorn, etc.)
    db.init_db(Config.DB_PATH)
